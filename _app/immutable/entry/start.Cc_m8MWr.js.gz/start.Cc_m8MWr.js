import{a as t}from"../chunks/entry.C_4GR4LI.js";export{t as start};
