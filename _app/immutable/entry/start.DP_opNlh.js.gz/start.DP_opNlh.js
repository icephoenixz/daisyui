import{a as t}from"../chunks/entry.NE7oY3gk.js";export{t as start};
