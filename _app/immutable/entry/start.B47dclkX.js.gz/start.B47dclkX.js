import{a as t}from"../chunks/entry.Dc7B4XmD.js";export{t as start};
