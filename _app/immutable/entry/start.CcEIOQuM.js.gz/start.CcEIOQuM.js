import{a as t}from"../chunks/entry.DzOi2p5c.js";export{t as start};
