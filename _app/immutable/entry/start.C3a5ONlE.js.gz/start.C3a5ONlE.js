import{a as t}from"../chunks/entry.DgS1qHgv.js";export{t as start};
